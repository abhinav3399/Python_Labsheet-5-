

data = input("Enter elements separated by space: ")
tuple1 = tuple(data.split())
length = len(tuple1) 
print("The tuple is:", tuple1)
print("Length of the tuple:", length)
