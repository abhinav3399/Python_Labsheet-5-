

data = input("Enter elements separated by space: ")
tuple1 = tuple(data.split())
element = input("Enter element to check: ")
if element in tuple1:
    print(element, "exists in the tuple.")
else:
    print(element, "does not exist in the tuple.")
