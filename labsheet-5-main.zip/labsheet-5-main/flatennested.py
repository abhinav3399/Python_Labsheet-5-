
nested_tuple = (("a", "b"), (1, 2), ("x", "y"))
flat_list = []
for group in nested_tuple:
    for item in group:
        flat_list.append(item)

flat_tuple = tuple(flat_list)

print("Nested tuple:", nested_tuple)
print("Flattened tuple:", flat_tuple)
