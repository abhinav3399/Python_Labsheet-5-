nested_tuple = (("apple", "banana"), (1, 2, 3), ("x", "y"))
print("Nested tuple:", nested_tuple)
print("First element of first tuple:", nested_tuple[0][0])
print("Second element of second tuple:", nested_tuple[1][1])
