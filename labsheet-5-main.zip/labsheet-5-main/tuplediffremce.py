

t1 = tuple(input("Enter first tuple: ").split())
t2 = tuple(input("Enter second tuple: ").split())

diff = []
for i in t1:
    if i not in t2:
        diff.append(i)

print("Tuple 1:", t1)
print("Tuple 2:", t2)
print("Difference (elements in tuple1 not in tuple2):", tuple(diff))
