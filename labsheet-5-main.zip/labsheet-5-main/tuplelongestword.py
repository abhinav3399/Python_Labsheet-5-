
words = tuple(input("Enter words: ").split())
max_length = 0
for word in words:
    if len(word) > max_length:
        max_length = len(word)

print("Words tuple:", words)
print("Length of longest word:", max_length)
