data1 = input("Enter first tuple elements separated by space: ")
tuple1 = tuple(data1.split())
data2 = input("Enter second tuple elements separated by space: ")
tuple2 = tuple(data2.split())
new_tuple = tuple1 + tuple2
print("First tuple:", tuple1)
print("Second tuple:", tuple2)
print("Concatenated tuple:", new_tuple)
