

t1 = tuple(map(int, input("Enter first tuple (numbers): ").split()))
t2 = tuple(map(int, input("Enter second tuple (numbers): ").split()))

result = []
if len(t1) == len(t2):
    for i in range(len(t1)):
        result.append(t1[i] + t2[i])
    result_tuple = tuple(result)
    print("First tuple:", t1)
    print("Second tuple:", t2)
    print("Element-wise sum:", result_tuple)
else:
    print("Tuples are of different lengths. Cannot perform element-wise sum.")
