tuple1 = ("Python", 10, 3.5, True)
print("Tuple with different data types:", tuple1)
