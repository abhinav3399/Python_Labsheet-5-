
data = input("Enter elements: ").split()
tuple1 = tuple(data)
reversed_tuple = tuple1[::-1]
print("Original tuple:", tuple1)
print("Reversed tuple:", reversed_tuple)
