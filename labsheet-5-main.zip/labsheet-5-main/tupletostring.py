data = input("Enter tuple elements: ").split()
tuple1 = tuple(data)
result = ""
for item in tuple1:
    result += item + " "
print("Tuple:", tuple1)
print("String:", result.strip())
