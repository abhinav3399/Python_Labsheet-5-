t1 = tuple(input("Enter first tuple: ").split())
t2 = tuple(input("Enter second tuple: ").split())
common = []
for i in t1:
    if i in t2 and i not in common:
        common.append(i)
print("Tuple 1:", t1)
print("Tuple 2:", t2)
print("Common elements:", tuple(common))
