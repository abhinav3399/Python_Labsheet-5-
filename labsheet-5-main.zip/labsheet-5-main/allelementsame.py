

data = input("Enter elements: ").split()
my_tuple = tuple(data)

all_same = True
for item in my_tuple:
    if item != my_tuple[0]:
        all_same = False
        break

print("Tuple:", my_tuple)
if all_same:
    print("All elements are same.")
else:
    print("All elements are not same.")
