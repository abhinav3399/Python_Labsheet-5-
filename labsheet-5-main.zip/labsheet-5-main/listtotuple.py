data = input("Enter list elements: ").split()
my_list = data
my_tuple = tuple(my_list)
print("List:", my_list)
print("Tuple:", my_tuple)
