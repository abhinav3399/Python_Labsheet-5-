data = input("Enter numbers: ").split()
nums = []
for i in data:
    nums.append(int(i))
tuple1 = tuple(nums)
sorted_list = list(tuple1)
sorted_list.sort()
sorted_tuple = tuple(sorted_list)
print("Original tuple:", tuple1)
print("Sorted tuple:", sorted_tuple)
