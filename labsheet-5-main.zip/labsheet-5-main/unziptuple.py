
data = [(1, "a"), (2, "b"), (3, "c")]
list1 = []
list2 = []
for pair in data:
    list1.append(pair[0])
    list2.append(pair[1])

print("Original list of tuples:", data)
print("First list:", list1)
print("Second list:", list2)
