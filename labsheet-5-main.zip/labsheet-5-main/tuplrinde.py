
data = input("Enter elements separated by space: ")
tuple1 = tuple(data.split())
element = input("Enter element to find index: ")
if element in tuple1:
    index = tuple1.index(element)
    print("The first index of", element, "is:", index)
else:
    print("Element not found in tuple.")
