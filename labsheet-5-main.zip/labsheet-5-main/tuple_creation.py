data = input("Enter elements separated by space: ")
elements = data.split()   # split into list
my_tuple = tuple(elements)  # convert list to tuple

print("The created tuple is:", my_tuple)
