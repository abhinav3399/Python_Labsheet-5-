data = input("Enter numbers separated by space: ").split()
numbers = []
for i in data:
    numbers.append(int(i))
tuple1 = tuple(numbers)
print("Tuple:", tuple1)
print("Maximum:", max(tuple1))
print("Minimum:", min(tuple1))
