

data = input("Enter elements: ").split()
my_tuple = tuple(data)

repeated = []
for item in my_tuple:
    if my_tuple.count(item) > 1 and item not in repeated:
        repeated.append(item)

print("Tuple:", my_tuple)
print("Repeated items:", tuple(repeated))
