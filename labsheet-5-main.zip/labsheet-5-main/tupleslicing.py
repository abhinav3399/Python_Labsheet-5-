

data = input("Enter elements separated by space: ")
tuple1 = tuple(data.split())
print("Tuple is:", tuple1)
start = int(input("Enter start index: "))
end = int(input("Enter end index: "))

print("Sliced tuple:", tuple1[start:end])
