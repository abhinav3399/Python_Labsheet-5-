data = input("Enter elements of the tuple separated by space: ")
tuple1 = tuple(data.split())
n = int(input("Enter number of times to repeat the tuple: "))
repeated_tuple = tuple1 * n
print("Original tuple:", tuple1)
print("Tuple repeated", n, "times:", repeated_tuple)
    