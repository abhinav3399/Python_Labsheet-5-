data = ((1, "apple"), (2, "banana"), (3, "cherry"))

my_dict = {}
for pair in data:
    my_dict[pair[0]] = pair[1]

print("Tuple of tuples:", data)
print("Converted dictionary:", my_dict)
