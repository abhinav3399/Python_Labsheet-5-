

data = input("Enter elements separated by space: ")
tuple1 = tuple(data.split())

print("Tuple is:", tuple1)

index = int(input("Enter the index to access element: "))

if index >= 0 and index < len(tuple1):
    print("Element at index", index, "is:", tuple1[index])
else:
    print("Invalid index!")
