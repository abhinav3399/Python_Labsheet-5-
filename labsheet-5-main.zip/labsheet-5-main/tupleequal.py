
t1 = tuple(input("Enter first tuple: ").split())
t2 = tuple(input("Enter second tuple: ").split())
if t1 == t2:
    print("Both tuples are equal.")
else:
    print("Tuples are not equal.")
