

data = input("Enter elements: ").split()
my_tuple = tuple(data)

unique_list = []
for item in my_tuple:
    if item not in unique_list:
        unique_list.append(item)

unique_tuple = tuple(unique_list)

print("Original tuple:", my_tuple)
print("Tuple without duplicates:", unique_tuple)
